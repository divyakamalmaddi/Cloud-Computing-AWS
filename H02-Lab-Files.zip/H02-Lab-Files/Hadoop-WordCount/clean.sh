rm -rf classes
rm wordcount.jar
rm -rf output
rm $HADOOP_HOME/bin/wordcount.jar 
rm $HADOOP_HOME-standalone/bin/wordcount.jar 

